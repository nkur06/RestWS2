package rest.store;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.ser.ContainerSerializer;

import runner.Student;

public class Repository {
	public static final List<Student> studentData = new ArrayList<Student>();

	public static void addStudent(Student student) {
		studentData.add(student);
	}

	public static boolean studentExists(Student stuObj) {
		return studentData.contains(stuObj);
	}

	public static boolean deleteStudent(int id) {

		return true;
	}
}
