package rest.constants;

public class Contstants {
	public static final String PATH_ADD_STUDENT = "/stu";
	public static final String ERROR_MSG_STUDENTALREADYPRESENT = "Person could not be added, this person is already added.";
	public static final String ERROR_CODE_STUDENTALREADYPRESENT = "100";

}
