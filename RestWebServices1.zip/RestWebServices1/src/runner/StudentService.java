package runner;

import java.net.URI;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.org.apache.bcel.internal.Constants;
import rest.constants.Contstants;
import org.json.JSONObject;
import rest.store.Repository;

@Path("/studentservice")
public class StudentService {
	private static final Logger log = Logger.getLogger(StudentService.class);

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String sayHelloHTML(@QueryParam("name") String name, @QueryParam("surname") String surname) {
		String resource = "<h1>Hi.. " + name + " " + surname + " . You are welcome in JNV Bareilly.</h1>";
		return resource;
	}

	@Path("/h")
	@GET
	@Consumes(MediaType.TEXT_XML)
	public Response sayHello() {
		String resource = "<? xml version='1.0' ?>".concat("<hello>You are welcome in JNV Bareilly.</hello>");
		return Response.status(200).entity(resource).build();
	}

	@Path("/p")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addStudent(@QueryParam("id") int id, @QueryParam("stuname") String stuname) {
		Response ret = null;
		Student student = new Student(id, stuname);
		if (student != null) {
			URI addPersonURI = URI.create("/p");
			if (!Repository.studentExists(student)) {
				Repository.addStudent(student);
				ret = Response.created(addPersonURI).entity(Repository.studentData).build();
			} else {
				ret = Response.status(400).entity(Contstants.ERROR_CODE_STUDENTALREADYPRESENT.concat(":")
						.concat(Contstants.ERROR_MSG_STUDENTALREADYPRESENT)).type(MediaType.TEXT_HTML).build();
			}
		}
		return ret;
	}

	@GET
	@Path("/g")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getAllStudents() {
		return Response.ok().entity(Repository.studentData).build();
	}

	@DELETE
	@Path("/d")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteStudent(@QueryParam("id") int id) {
		Student stu = new Student(id);
		Repository.studentData.remove(stu);
		return Response.ok().entity(Repository.studentData).build();
	}
}
