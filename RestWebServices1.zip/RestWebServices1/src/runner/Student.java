package runner;

public class Student {
	private int studentId;
	private String studentName;

	public Student(int studentId, String studentName) {
		this.studentId = studentId;
		this.studentName = studentName;
	}

	public Student(int studentId) {
		this.studentId = studentId;
	}

	public int getStudentId() {
		return this.studentId;
	}

	public void setStudentId(int value) {
		this.studentId = value;

	}

	public String getStudentName() {
		return this.studentName;
	}

	public void setStudentName(String value) {
		this.studentName = value;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Student) {
			int studentIdNew = ((Student) obj).getStudentId();
			return studentId == studentIdNew;
		}

		return false;
	}

}
